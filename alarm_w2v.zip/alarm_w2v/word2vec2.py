#!/usr/bin/env python
# -*- coding: utf-8 -*-
import codecs
import json
import time
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
import gensim

#warnings.filterwarnings("ignore")
with codecs.open("./data/test.txt", "r", "utf-8") as json_file:
    data = json.load(json_file)

sentence = []
first_time = time.strptime(data[0]["_source"]["@timestamp"], "%Y-%m-%dT%H:%M:%S.%fZ")
timeId = time.mktime(first_time)  # 初始化时间Id
sentence_list = []
for content in data:
    alarm_word = content["_source"]["title"]
    #print(alarm_word)
    alarm_time = time.strptime(content["_source"]["@timestamp"], "%Y-%m-%dT%H:%M:%S.%fZ")
    alarm_time = time.mktime(alarm_time)
    #print(alarm_time)
    if (int(alarm_time / 120)) == timeId:  # 2分钟粒度  120秒，选取合适的时间粒度的告警标题作为一行句子（或者文档）
        sentence.append(alarm_word)
    else:
        if sentence:
            sentence_list.append(sentence)
        timeId = int(alarm_time / 120)
        sentence = []
 
model = gensim.models.Word2Vec(sentence_list, sg=0,min_count=3, iter=100, size=200)
result = model.most_similar(u"CPU利用率过高告警",topn=10)
print("-------告警：【CPU利用率过高告警】 关联度大于90%的相关告警---------")
for s in result:
    if s[1] > 0.9:
        print(s[0] + ' -> ' + str(s[1]))
