# -*- coding: utf-8 -*-
import jieba
import matplotlib.pyplot as plt
import numpy as np
import warnings
warnings.filterwarnings(action='ignore', category=DeprecationWarning, module='word2vec')


from gensim.models import word2vec
from matplotlib.font_manager import *  
from sklearn.manifold import TSNE

# 获取停用词列表
stop_words = list()
stopwords_file = "./data/stop_words.txt"
stop_f = open(stopwords_file,"r",encoding='utf-8')
for line in stop_f.readlines():
    line = line.strip()
    if not len(line):
        continue
    stop_words.append(line)
stop_f.close()
 
# 用jieba进行分词并保存分词后的文件
sentencesList =list()
comments = ""
commentFile = "./data/comment.txt"
comment_f =  open(commentFile,"r",encoding="utf-8") 
for line in comment_f.readlines():
      sentenceTmp = list()
      segs  =  jieba.cut(line.strip(),cut_all = False)
      for word in segs :
        word = word.strip()
        # print(word)
        if word not in stop_words and word != '' :
            sentenceTmp.append(word)
      if len(sentenceTmp)> 0 :
        comment = ' '.join(sentenceTmp) +"\n"
        comments = comments + comment
        print( comments )

comment_f.close();

fo = open("./data/segments.txt","w",encoding='utf-8')
fo.write(comments)
fo.close()


sentences=word2vec.Text8Corpus(u'./data/segments.txt')

# 第一个参数是训练语料；第二个参数是忽略词频小于此值的单词； 第三个参数word向量的维度；第四个参数是一个句子中当前单词和被预测单词的最大距离；workers是训练模型时使用的线程数
# warnings.filterwarnings("ignore")
model=word2vec.Word2Vec(sentences,min_count=3, size=60, window=5, workers=1)

print("-------技术相关的关键词---------")
#计算余弦距离最接近“技术”的10个词，也就是相似度最高的10个词
for i in model.wv.most_similar(u"技术",topn=10): 
    print(i[0],i[1])

 
#根据训练后留下的分词，获取词向量矩阵
vecWords = list()
vecArray= []
for word in model.wv.index2word:
    vec = model.wv[word]
    vecWords.append( word)
    vecArray.append(vec);
vecArray = np.array(vecArray)


# 由于随机数种子没有固定，降维运算结果每次都不同，所以需要固定随机数种子random_state的数值（取整），便于重现调整上述训练模型后的效果
X_tsne = TSNE(n_components=2,learning_rate=100,random_state=2000).fit_transform(vecArray)
plt.figure('词向量距离',figsize=(14, 8))
plt.rcParams['font.sans-serif'] = ['SimHei'] #用来正常显示中文标签，如果不设置，中文显示乱码
plt.rcParams['axes.unicode_minus'] = False #用来正常显示负号
plt.scatter(X_tsne[:,0],X_tsne[:,1]) #画点

for i in range(len(vecArray)):
    x=X_tsne[i][0]
    y=X_tsne[i][1]
    plt.text(x , y ,vecWords[i],size = 12)

plt.show()